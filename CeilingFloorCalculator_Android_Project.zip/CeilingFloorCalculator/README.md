Armstrong Ceiling Calculator — Edge Cross-Tee Fix

This project is the Armstrong-only calculator with 600 × 600 mm boards. The live ceiling grid preview now draws both 1200 mm cross-tee segments and 600 mm cross-tee segments in all bays: between adjacent main runners and in the edge bays between the wall angle and the outermost main runners. Edge segments are schematic and may need cutting to fit actual room dimensions.

Validation performed: ZIP integrity and JavaScript syntax check. An Android Gradle build and on-device test have not been run here.
