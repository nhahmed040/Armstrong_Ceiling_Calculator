# Armstrong Ceiling Calculator — Version 4

Android WebView application for Armstrong 600 × 600 mm ceiling layout and material estimating.

## Version 4 updates
- Added editable grid-component prices (default ETB): main runner 700/bar, wall angle 450/bar, 1,200 mm tee 300/pc, 600 mm tee 200/pc.
- Added market purchasing allowances: runners area × 0.20; wall angles area × 0.22; each cross-tee type area × 1.22. Each allowance is rounded up to whole units.
- Final grid purchase quantity is the greater of the market allowance and the exact plan/linear-length requirement. Additional quantity is shown separately.
- Main-runner and wall-angle default purchasing quantities use total installed linear length divided by stock length, rounded up. Detailed cut/offcut figures are secondary estimates.
- Board quantities remain unrounded per room. Boxes of 10 are rounded up once against the combined project board requirement.
- Updated material cost totals and CSV/PDF reporting.

## Build APK
Open the repository in GitHub and run the **Build Android APK** workflow under Actions (or push to `main`/`master`). Download the `CeilingFloorCalculator-debug-apk` artifact after the workflow succeeds.

APK build and on-device testing have not yet been performed for this version.
