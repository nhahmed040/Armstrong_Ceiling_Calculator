# Armstrong Ceiling Calculator

Version 3 updated to a dedicated Armstrong ceiling estimator with a live interactive 600 x 600 mm grid preview.

Build using the included GitHub Actions workflow.
