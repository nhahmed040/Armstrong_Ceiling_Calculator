# Ceiling & Floor Calculator Android App — Version 2.0

Offline Android WebView app for estimating ceiling board and floor tile quantities and ETB costs.

## Version 2.0 updates
- Separate Ceiling Calculator and Floor Tile Calculator tabs.
- Default one room/row measuring 6 m × 6 m (36 m²).
- Ceiling board size 1200 × 600 mm and default 10 boards per box.
- Floor tile size options: 400 × 400 mm, 1200 × 600 mm, and 300 × 300 mm.
- Keeps decimal precision for intermediate calculations and rounds purchase quantities up in the summary.
- Generic material wording (brand name removed).
- CSV export uses Android's Save As document picker.
- Construction-themed logo used in the app header and launcher icon.

## Build online using GitHub Actions
Upload `CeilingFloorCalculator_Android_Project.zip` to the root of your GitHub repository. Add the supplied workflow file at `.github/workflows/build-apk.yml`, then open **Actions** and run **Build Ceiling and Floor Calculator APK**. Download the `CeilingFloorCalculator-debug-apk` artifact from a successful run.

## Notes
- Material rates and waste percentages are editable estimating assumptions.
- Tile box counts are not guessed because coverage per box depends on the supplier/packaging.
- Verify the selected material specifications and quantities with suppliers before ordering.


Version 2 corrections: restores 6 m x 6 m default room and one room row; floor tile options 600x600, 400x400, 1200x600, 300x300 mm; ceiling board options 600x600 and 1200x600 mm; editable tiles-per-box and full-box/leftover calculation; Android native Print Framework integration for Print / Save PDF.
