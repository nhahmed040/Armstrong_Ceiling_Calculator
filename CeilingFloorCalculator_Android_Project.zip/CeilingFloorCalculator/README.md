# Ceiling & Floor Calculator — Android project

Offline-first Android WebView app based on the formulas in `Ceiling_and_Floor_Calculator.xlsx`.

## Included
- Add/remove rooms and edit length/width in metres.
- Editable ceiling and tile unit rates, plus waste percentages.
- Ceiling runner, cross tee, wall angle, board, board box, tile piece and tile box quantities.
- Estimated costs and material weight totals.
- CSV export and Android print dialog (Save as PDF where supported).
- All calculations run locally; no internet permission is requested.

## Build APK in Android Studio
1. Install Android Studio and its Android SDK (API 35 or a compatible installed SDK).
2. Open this folder (`CeilingFloorCalculator`) as a project.
3. Let Gradle sync and install any requested SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Calculation notes
The workbook's core formulas are reflected: 3.6 m runners per 4.32 m²; 1.2 m and 0.6 m cross tees per 0.72 m²; 3.0 m wall angle per 3 m of perimeter; boards per 0.36 m²; 16 boards per box; tile pieces per 0.36 m²; 1.44 m² per tile box; ceiling rate defaults to 1500 ETB/m² and tile rate to 1150 ETB/m². Default waste is 5% ceiling and 10% tiles. Weight estimates use the workbook's per-item weights. Purchase quantities round upward.

This is an initial app conversion of the workbook's formulas, not a certified bill of quantities. Verify formulas, product packaging, prices, and site-specific allowances before procurement.
